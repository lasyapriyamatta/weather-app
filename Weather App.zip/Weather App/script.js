async function getWeather() {
    const city = document.getElementById('cityInput').value.trim();
  
    if (city === '') {
      document.getElementById('weatherResult').innerHTML = "<p>Please enter a city name.</p>";
      return;
    }
  
    const apiKey = '867ccf7791777b954e5de473069ba4b7';  // <-- Replace with your API key
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;
  
    try {
      const response = await fetch(url);
      if (!response.ok) throw new Error('City not found');
  
      const data = await response.json();
      const iconCode = data.weather[0].icon;
      const iconUrl = `https://openweathermap.org/img/wn/${iconCode}@2x.png`;
  
      const weatherResult = `
        <h2>${data.name}</h2>
        <img src="${iconUrl}" alt="${data.weather[0].description}">
        <p><strong>${data.weather[0].main}</strong>: ${data.weather[0].description}</p>
        <p>Temperature: ${data.main.temp}°C</p>
        <p>Humidity: ${data.main.humidity}%</p>
        <p>Wind: ${data.wind.speed} m/s</p>
      `;
      document.getElementById('weatherResult').innerHTML = weatherResult;
    } catch (error) {
      document.getElementById('weatherResult').innerHTML = `<p>${error.message}</p>`;
    }
  }
  